'use client'

import { useState } from 'react'
import {
  ArrowRight,
  Bookmark,
  Check,
  Clock3,
  Copy,
  Lightbulb,
  LoaderCircle,
  Menu,
  RefreshCw,
  Sparkles,
  Target,
  WandSparkles,
  X,
  Zap,
} from 'lucide-react'
import { Button } from '@/components/ui/button'

type Idea = {
  id: number
  title: string
  problem: string
  solution: string
  features: string[]
  technologies: string[]
  difficulty: string
  estimatedTime: string
}

const baseIdeas = [
  {
    title: 'FocusFlow Study Planner',
    problem: 'Students struggle to turn a busy semester schedule into a realistic daily study plan.',
    solution: 'A smart planner that breaks assignments into focused sessions and adapts when plans change.',
    features: ['Assignment breakdown', 'Focus timer', 'Calendar sync', 'Progress insights'],
    technologies: ['Next.js', 'TypeScript', 'PostgreSQL'],
    estimatedTime: '2–3 weeks',
  },
  {
    title: 'CampusConnect Exchange',
    problem: 'Students have useful books, furniture, and supplies but no trusted place to exchange them locally.',
    solution: 'A student-only marketplace with campus verification, smart categories, and safe meet-up suggestions.',
    features: ['Verified profiles', 'Image listings', 'Smart filters', 'Chat prompts'],
    technologies: ['React', 'Node.js', 'MongoDB'],
    estimatedTime: '3–4 weeks',
  },
  {
    title: 'Wellness Check-In',
    problem: 'Small signs of stress are easy to miss when students are balancing classes, work, and social life.',
    solution: 'A private check-in app that spots patterns and recommends small, practical wellness actions.',
    features: ['Mood check-ins', 'Trend dashboard', 'Resource library', 'Gentle reminders'],
    technologies: ['React Native', 'Firebase', 'Python'],
    estimatedTime: '2–3 weeks',
  },
  {
    title: 'SkillSwap Campus',
    problem: 'Students want to learn from one another but rarely know who has the skills they need.',
    solution: 'A peer learning network that matches students for short, structured skill exchanges.',
    features: ['Skill profiles', 'Match suggestions', 'Session requests', 'Ratings'],
    technologies: ['Next.js', 'Supabase', 'Tailwind CSS'],
    estimatedTime: '3–5 weeks',
  },
  {
    title: 'GreenRoute Tracker',
    problem: 'Campus commuters cannot easily compare the environmental impact of different ways to get to class.',
    solution: 'A lightweight tracker that compares walking, biking, transit, and carpooling over time.',
    features: ['Route logging', 'Impact estimates', 'Leaderboards', 'Weekly goals'],
    technologies: ['React', 'Mapbox', 'Express'],
    estimatedTime: '2–4 weeks',
  },
]

const domainTech: Record<string, string[]> = {
  'Artificial Intelligence': ['Python', 'FastAPI', 'Vector database'],
  'Web Development': ['Next.js', 'TypeScript', 'PostgreSQL'],
  'Mobile App': ['React Native', 'Expo', 'Firebase'],
  IoT: ['Arduino', 'MQTT', 'Node.js'],
  'Data Science': ['Python', 'Pandas', 'Streamlit'],
  Cybersecurity: ['Python', 'Linux', 'OWASP'],
  'Cloud Computing': ['Next.js', 'AWS Lambda', 'DynamoDB'],
}

function createIdeas(topic: string, difficulty: string, domain: string): Idea[] {
  const cleanTopic = topic.trim()
  const subject = cleanTopic || 'student life'
  const tech = domainTech[domain] ?? ['React', 'Node.js', 'MongoDB']

  return baseIdeas.map((idea, index) => ({
    ...idea,
    id: Date.now() + index,
    title: index === 0 ? `${subject.split(' ').slice(0, 3).join(' ')} ${idea.title.split(' ').slice(-2).join(' ')}` : idea.title,
    problem: `${idea.problem.replace('.', '')} This concept focuses on ${subject.toLowerCase()}.`,
    technologies: domain === 'Any' ? idea.technologies : tech,
    difficulty,
  }))
}

function LogoMark() {
  return (
    <div className="relative flex size-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white shadow-lg shadow-indigo-200">
      <Sparkles aria-hidden="true" className="size-5" />
      <span className="absolute -right-0.5 -top-0.5 size-2 rounded-full bg-cyan-300" />
    </div>
  )
}

function IdeaCard({ idea, saved, onSave, onCopy }: { idea: Idea; saved: boolean; onSave: () => void; onCopy: () => void }) {
  return (
    <article className="group flex h-full flex-col rounded-2xl border border-slate-200/80 bg-white p-5 shadow-[0_12px_40px_-24px_rgba(71,85,105,0.45)] transition-all hover:-translate-y-1 hover:border-indigo-200 hover:shadow-[0_18px_45px_-22px_rgba(79,70,229,0.3)] sm:p-6">
      <div className="mb-5 flex items-start justify-between gap-3">
        <div className="flex size-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
          <Lightbulb aria-hidden="true" className="size-5" />
        </div>
        <div className="flex items-center gap-2">
          <button aria-label={`Copy ${idea.title}`} onClick={onCopy} className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-indigo-600">
            <Copy aria-hidden="true" className="size-4" />
          </button>
          <button aria-label={`${saved ? 'Unsave' : 'Save'} ${idea.title}`} onClick={onSave} className={`rounded-lg p-2 transition ${saved ? 'bg-indigo-50 text-indigo-600' : 'text-slate-400 hover:bg-slate-100 hover:text-indigo-600'}`}>
            <Bookmark aria-hidden="true" className="size-4" fill={saved ? 'currentColor' : 'none'} />
          </button>
        </div>
      </div>
      <h3 className="text-lg font-bold tracking-tight text-slate-900">{idea.title}</h3>
      <div className="mt-5 flex flex-col gap-4 text-sm leading-6">
        <div><p className="mb-1 text-xs font-bold uppercase tracking-[0.14em] text-indigo-600">Problem</p><p className="text-slate-600">{idea.problem}</p></div>
        <div><p className="mb-1 text-xs font-bold uppercase tracking-[0.14em] text-indigo-600">Solution</p><p className="text-slate-600">{idea.solution}</p></div>
        <div><p className="mb-2 text-xs font-bold uppercase tracking-[0.14em] text-indigo-600">Key features</p><ul className="grid grid-cols-1 gap-1.5 text-slate-600 sm:grid-cols-2">{idea.features.map((feature) => <li key={feature} className="flex items-center gap-2"><span className="size-1.5 rounded-full bg-cyan-400" />{feature}</li>)}</ul></div>
      </div>
      <div className="mt-auto flex flex-col gap-4 border-t border-slate-100 pt-5 sm:flex-row sm:items-end sm:justify-between">
        <div><p className="mb-1 text-xs font-bold uppercase tracking-[0.14em] text-indigo-600">Technologies</p><div className="flex flex-wrap gap-1.5">{idea.technologies.map((technology) => <span key={technology} className="rounded-md bg-slate-100 px-2 py-1 text-xs font-medium text-slate-600">{technology}</span>)}</div></div>
        <div className="shrink-0 text-left sm:text-right"><p className="flex items-center gap-1 text-xs font-bold uppercase tracking-[0.14em] text-indigo-600 sm:justify-end"><Clock3 aria-hidden="true" className="size-3" /> Time</p><p className="mt-1 text-sm font-semibold text-slate-800">{idea.estimatedTime}</p><p className="text-xs text-slate-500">{idea.difficulty}</p></div>
      </div>
    </article>
  )
}

export default function Page() {
  const [topic, setTopic] = useState('')
  const [difficulty, setDifficulty] = useState('Intermediate')
  const [domain, setDomain] = useState('Any')
  const [ideas, setIdeas] = useState<Idea[]>([])
  const [savedIdeas, setSavedIdeas] = useState<Idea[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [error, setError] = useState('')
  const [copiedId, setCopiedId] = useState<number | null>(null)

  function generate() {
    if (!topic.trim()) {
      setError('Tell us about a problem or topic first, and we’ll spark some ideas.')
      return
    }
    setError('')
    setIsGenerating(true)
    window.setTimeout(() => {
      setIdeas(createIdeas(topic, difficulty, domain))
      setIsGenerating(false)
    }, 1200)
  }

  function toggleSave(idea: Idea) {
    setSavedIdeas((current) => current.some((saved) => saved.id === idea.id) ? current.filter((saved) => saved.id !== idea.id) : [...current, idea])
  }

  async function copyIdea(idea: Idea) {
    await navigator.clipboard?.writeText(`${idea.title}\n\nProblem: ${idea.problem}\nSolution: ${idea.solution}\nFeatures: ${idea.features.join(', ')}\nTechnologies: ${idea.technologies.join(', ')}`)
    setCopiedId(idea.id)
    window.setTimeout(() => setCopiedId(null), 1600)
  }

  return (
    <main className="min-h-screen overflow-hidden bg-[#f8faff] text-slate-900">
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-0 h-[580px] overflow-hidden bg-[radial-gradient(circle_at_15%_0%,rgba(129,140,248,0.18),transparent_36%),radial-gradient(circle_at_90%_10%,rgba(34,211,238,0.12),transparent_30%)]" />
      <header className="relative z-10 border-b border-slate-200/70 bg-white/75 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4 sm:px-8 lg:px-10">
          <a href="#top" className="flex items-center gap-3"><LogoMark /><span className="text-sm font-bold tracking-tight text-slate-900 sm:text-base">IdeaSpark<span className="text-indigo-600">.ai</span></span></a>
          <nav className="hidden items-center gap-7 text-sm font-medium text-slate-500 md:flex"><a href="#ideas" className="transition hover:text-indigo-600">Explore ideas</a><a href="#how-it-works" className="transition hover:text-indigo-600">How it works</a>{savedIdeas.length > 0 && <a href="#saved" className="transition hover:text-indigo-600">Saved ({savedIdeas.length})</a>}</nav>
          <button aria-label="Open navigation" className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 md:hidden"><Menu aria-hidden="true" className="size-5" /></button>
        </div>
      </header>

      <div id="top" className="relative z-10 mx-auto max-w-6xl px-5 pb-20 pt-14 sm:px-8 sm:pt-20 lg:px-10">
        <section className="mx-auto max-w-3xl text-center">
          <div className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-indigo-100 bg-white/80 px-3 py-1.5 text-xs font-bold text-indigo-600 shadow-sm"><Zap aria-hidden="true" className="size-3.5 fill-current" />AI POWERED</div>
          <h1 className="text-balance text-4xl font-extrabold tracking-[-0.04em] text-slate-950 sm:text-6xl">Turn curiosity into <span className="bg-gradient-to-r from-indigo-600 via-violet-600 to-cyan-500 bg-clip-text text-transparent">something real.</span></h1>
          <p className="mx-auto mt-5 max-w-2xl text-pretty text-base leading-7 text-slate-600 sm:text-lg">Turn your problems and interests into innovative project ideas with AI.</p>
        </section>

        <section className="mx-auto mt-10 max-w-4xl rounded-3xl border border-white/80 bg-white p-5 shadow-[0_24px_70px_-34px_rgba(79,70,229,0.35)] sm:p-8">
          <div className="mb-7 flex items-center gap-3"><div className="flex size-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600"><Target aria-hidden="true" className="size-5" /></div><div><h2 className="font-bold text-slate-900">What would you like to build?</h2><p className="text-sm text-slate-500">Give us a starting point and we’ll do the brainstorming.</p></div></div>
          <div className="flex flex-col gap-6">
            <div><label htmlFor="topic" className="mb-2 block text-sm font-semibold text-slate-700">What problem or topic are you interested in?</label><textarea id="topic" value={topic} onChange={(event) => { setTopic(event.target.value); if (error) setError('') }} placeholder="Example: Problems faced by college students..." rows={4} aria-invalid={Boolean(error)} className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50/60 px-4 py-3.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-indigo-400 focus:bg-white focus:ring-4 focus:ring-indigo-100" />{error && <p className="mt-2 flex items-center gap-1.5 text-sm font-medium text-rose-600"><X aria-hidden="true" className="size-4" />{error}</p>}</div>
            <div className="grid gap-5 sm:grid-cols-2"><div><label htmlFor="difficulty" className="mb-2 block text-sm font-semibold text-slate-700">Difficulty level</label><select id="difficulty" value={difficulty} onChange={(event) => setDifficulty(event.target.value)} className="w-full appearance-none rounded-xl border border-slate-200 bg-slate-50/60 px-4 py-3 text-sm text-slate-800 outline-none transition focus:border-indigo-400 focus:bg-white focus:ring-4 focus:ring-indigo-100"><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select></div><div><label htmlFor="domain" className="mb-2 block text-sm font-semibold text-slate-700">Technology / domain</label><select id="domain" value={domain} onChange={(event) => setDomain(event.target.value)} className="w-full appearance-none rounded-xl border border-slate-200 bg-slate-50/60 px-4 py-3 text-sm text-slate-800 outline-none transition focus:border-indigo-400 focus:bg-white focus:ring-4 focus:ring-indigo-100"><option>Any</option>{Object.keys(domainTech).map((item) => <option key={item}>{item}</option>)}</select></div></div>
            <Button onClick={generate} disabled={isGenerating} className="h-12 w-full rounded-xl bg-indigo-600 text-sm font-bold text-white shadow-lg shadow-indigo-200 transition hover:bg-indigo-700 hover:shadow-indigo-300">{isGenerating ? <><LoaderCircle data-icon="inline-start" className="animate-spin" />Creating your ideas...</> : <><WandSparkles data-icon="inline-start" />Generate Project Ideas</>}</Button>
          </div>
        </section>

        {isGenerating && <div className="mx-auto mt-12 flex max-w-4xl flex-col items-center gap-3 py-8 text-center"><div className="flex size-14 items-center justify-center rounded-2xl bg-indigo-100 text-indigo-600"><LoaderCircle className="size-7 animate-spin" /></div><p className="font-semibold text-slate-800">Finding a few directions worth exploring...</p><p className="text-sm text-slate-500">Mixing your interests with practical project patterns</p></div>}

        {ideas.length > 0 && !isGenerating && <section id="ideas" className="mt-16 scroll-mt-8"><div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><p className="mb-2 text-xs font-bold uppercase tracking-[0.18em] text-indigo-600">Your starting point</p><h2 className="text-2xl font-extrabold tracking-tight text-slate-950 sm:text-3xl">Ideas made for you</h2><p className="mt-2 text-sm text-slate-500">Here are five directions to take from <span className="font-semibold text-slate-700">{topic}</span>.</p></div><Button variant="outline" onClick={generate} className="w-fit rounded-lg border-slate-200 bg-white text-slate-700 hover:border-indigo-200 hover:text-indigo-600"><RefreshCw data-icon="inline-start" />Regenerate ideas</Button></div><div className="grid gap-5 lg:grid-cols-2">{ideas.map((idea) => <IdeaCard key={idea.id} idea={idea} saved={savedIdeas.some((saved) => saved.id === idea.id)} onSave={() => toggleSave(idea)} onCopy={() => copyIdea(idea)} />)}</div></section>}

        {savedIdeas.length > 0 && <section id="saved" className="mt-16 scroll-mt-8"><div className="mb-7 flex items-end justify-between"><div><p className="mb-2 text-xs font-bold uppercase tracking-[0.18em] text-cyan-600">Your collection</p><h2 className="text-2xl font-extrabold tracking-tight text-slate-950 sm:text-3xl">Saved ideas</h2></div><span className="rounded-full bg-cyan-50 px-3 py-1 text-sm font-bold text-cyan-700">{savedIdeas.length} saved</span></div><div className="grid gap-5 lg:grid-cols-2">{savedIdeas.map((idea) => <IdeaCard key={`saved-${idea.id}`} idea={idea} saved onSave={() => toggleSave(idea)} onCopy={() => copyIdea(idea)} />)}</div></section>}

        <section id="how-it-works" className="mt-24 scroll-mt-8 border-t border-slate-200/80 pt-16"><div className="mx-auto max-w-2xl text-center"><p className="mb-2 text-xs font-bold uppercase tracking-[0.18em] text-indigo-600">Simple by design</p><h2 className="text-2xl font-extrabold tracking-tight text-slate-950 sm:text-3xl">How it works</h2><p className="mt-3 text-slate-500">From a rough thought to a buildable direction in three simple steps.</p></div><div className="mt-10 grid gap-5 md:grid-cols-3">{[['01','Enter your problem','Tell the AI what problem or topic interests you.'],['02','AI generates ideas','The system analyzes your input and creates project concepts.'],['03','Start building','Choose an idea and start developing your project.']].map(([number, title, description], index) => <div key={number} className="relative rounded-2xl border border-slate-200/80 bg-white p-6 shadow-sm"><span className="text-4xl font-black tracking-[-0.06em] text-indigo-100">{number}</span><div className="mt-5 flex size-10 items-center justify-center rounded-xl bg-slate-50 text-indigo-600">{index === 0 ? <Target className="size-5" /> : index === 1 ? <Sparkles className="size-5" /> : <ArrowRight className="size-5" />}</div><h3 className="mt-4 font-bold text-slate-900">{title}</h3><p className="mt-2 text-sm leading-6 text-slate-500">{description}</p></div>)}</div></section>

        <footer className="mt-20 flex flex-col gap-4 border-t border-slate-200/80 pt-8 text-sm text-slate-500 sm:flex-row sm:items-center sm:justify-between"><p>Built for students <span className="mx-1 text-indigo-400">•</span> AI Project Idea Generator</p><div className="flex items-center gap-5"><a href="https://github.com" target="_blank" rel="noreferrer" className="transition hover:text-indigo-600">GitHub</a><a href="#how-it-works" className="transition hover:text-indigo-600">About</a></div></footer>
      </div>
      {copiedId !== null && <div role="status" className="fixed bottom-5 left-1/2 z-20 flex -translate-x-1/2 items-center gap-2 rounded-full bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white shadow-xl"><Check className="size-4 text-emerald-300" />Idea copied to clipboard</div>}
    </main>
  )
}

